
-- Enums
CREATE TYPE public.app_role AS ENUM ('admin', 'user');
CREATE TYPE public.asset_status AS ENUM ('available','assigned','in_repair','lost','retired');
CREATE TYPE public.asset_category AS ENUM ('laptop','server','switch','printer','monitor','mobile','keyboard','other');
CREATE TYPE public.ticket_priority AS ENUM ('low','medium','high','critical');
CREATE TYPE public.ticket_status AS ENUM ('open','in_progress','resolved','closed');

-- Timestamp trigger
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$ LANGUAGE plpgsql SET search_path = public;

-- Profiles
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT,
  full_name TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Profiles readable by authenticated" ON public.profiles FOR SELECT TO authenticated USING (true);
CREATE POLICY "Users update own profile" ON public.profiles FOR UPDATE TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);
CREATE TRIGGER trg_profiles_updated BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- User roles
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role app_role NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(user_id, role)
);
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users read own roles" ON public.user_roles FOR SELECT TO authenticated USING (user_id = auth.uid());

CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role app_role)
RETURNS BOOLEAN LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS(SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role);
$$;

-- Auto-create profile + default role on signup; first user becomes admin
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  is_first BOOLEAN;
BEGIN
  INSERT INTO public.profiles (id, email, full_name)
  VALUES (NEW.id, NEW.email, COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.raw_user_meta_data->>'name', split_part(NEW.email,'@',1)));
  SELECT COUNT(*) = 0 INTO is_first FROM public.user_roles;
  INSERT INTO public.user_roles (user_id, role)
  VALUES (NEW.id, CASE WHEN is_first THEN 'admin'::app_role ELSE 'user'::app_role END);
  RETURN NEW;
END; $$;

CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Assets
CREATE TABLE public.assets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  serial TEXT NOT NULL UNIQUE,
  category asset_category NOT NULL DEFAULT 'other',
  status asset_status NOT NULL DEFAULT 'available',
  assigned_to TEXT,
  purchased_at DATE,
  warranty_expiry DATE,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.assets TO authenticated;
GRANT INSERT, UPDATE, DELETE ON public.assets TO authenticated;
GRANT ALL ON public.assets TO service_role;
ALTER TABLE public.assets ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Assets viewable by authenticated" ON public.assets FOR SELECT TO authenticated USING (true);
CREATE POLICY "Admins insert assets" ON public.assets FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE POLICY "Admins update assets" ON public.assets FOR UPDATE TO authenticated USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE POLICY "Admins delete assets" ON public.assets FOR DELETE TO authenticated USING (public.has_role(auth.uid(),'admin'));
CREATE TRIGGER trg_assets_updated BEFORE UPDATE ON public.assets FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Licenses
CREATE TABLE public.licenses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  vendor TEXT,
  seats_total INT NOT NULL DEFAULT 1,
  seats_used INT NOT NULL DEFAULT 0,
  key_ref TEXT,
  expiry DATE,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.licenses TO authenticated;
GRANT ALL ON public.licenses TO service_role;
ALTER TABLE public.licenses ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Licenses viewable by authenticated" ON public.licenses FOR SELECT TO authenticated USING (true);
CREATE POLICY "Admins insert licenses" ON public.licenses FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE POLICY "Admins update licenses" ON public.licenses FOR UPDATE TO authenticated USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE POLICY "Admins delete licenses" ON public.licenses FOR DELETE TO authenticated USING (public.has_role(auth.uid(),'admin'));
CREATE TRIGGER trg_licenses_updated BEFORE UPDATE ON public.licenses FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Tickets
CREATE TABLE public.tickets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  ticket_no SERIAL UNIQUE,
  asset_id UUID REFERENCES public.assets(id) ON DELETE SET NULL,
  title TEXT NOT NULL,
  description TEXT,
  priority ticket_priority NOT NULL DEFAULT 'medium',
  status ticket_status NOT NULL DEFAULT 'open',
  raised_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  raised_by_name TEXT,
  engineer TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.tickets TO authenticated;
GRANT ALL ON public.tickets TO service_role;
ALTER TABLE public.tickets ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Tickets viewable by authenticated" ON public.tickets FOR SELECT TO authenticated USING (true);
CREATE POLICY "Users create tickets" ON public.tickets FOR INSERT TO authenticated WITH CHECK (auth.uid() = raised_by);
CREATE POLICY "Admins update tickets" ON public.tickets FOR UPDATE TO authenticated USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE POLICY "Admins delete tickets" ON public.tickets FOR DELETE TO authenticated USING (public.has_role(auth.uid(),'admin'));
CREATE TRIGGER trg_tickets_updated BEFORE UPDATE ON public.tickets FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Seed data
INSERT INTO public.assets (name, serial, category, status, assigned_to, warranty_expiry) VALUES
  ('ThinkPad X1 Carbon G11','PF3XK9A2','laptop','assigned','Ravi Sharma','2027-03-01'),
  ('MacBook Pro 14 M3','C02ZK1LMQ6L4','laptop','assigned','Priya Nair','2027-06-15'),
  ('Dell PowerEdge R650','SVR-DL650-01','server','available',NULL,'2028-01-10'),
  ('Cisco Catalyst 9200','FOC2412X0KL','switch','in_repair',NULL,'2026-11-20'),
  ('HP LaserJet Pro M404','VNC4H12093','printer','assigned','Front Desk','2026-08-05'),
  ('Dell U2723QE Monitor','MON-U27-014','monitor','available',NULL,'2027-09-30'),
  ('iPhone 15 Pro','F2LWK3JXQ1','mobile','lost','—','2026-12-01'),
  ('Logitech MX Keys','KB-MXK-221','keyboard','retired',NULL,NULL);

INSERT INTO public.licenses (name, vendor, seats_total, seats_used, expiry) VALUES
  ('Adobe Creative Cloud','Adobe',25,22,'2026-08-12'),
  ('JetBrains All Products','JetBrains',15,11,'2026-08-19'),
  ('Microsoft 365 E3','Microsoft',120,108,'2026-09-01'),
  ('Zoom Workplace','Zoom',80,64,'2027-02-14'),
  ('1Password Business','1Password',60,55,'2027-05-30');

INSERT INTO public.tickets (asset_id, title, description, priority, status, raised_by_name, engineer)
SELECT id, 'Battery drains within 2 hours of unplug','Battery health degrading rapidly','high','in_progress','Ravi Sharma','N. Iyer' FROM public.assets WHERE serial='PF3XK9A2';
INSERT INTO public.tickets (asset_id, title, description, priority, status, raised_by_name, engineer)
SELECT id, 'Port 12 stuck in err-disabled','Repeated flaps on uplink','critical','open','NetOps','—' FROM public.assets WHERE serial='FOC2412X0KL';
INSERT INTO public.tickets (asset_id, title, description, priority, status, raised_by_name, engineer)
SELECT id, 'External display flickers on HDMI','Happens with 4K monitor','medium','open','Priya Nair','—' FROM public.assets WHERE serial='C02ZK1LMQ6L4';
INSERT INTO public.tickets (asset_id, title, description, priority, status, raised_by_name, engineer)
SELECT id, 'Paper jam recurring at tray 2','Feeder rollers worn','low','resolved','Front Desk','S. Kapoor' FROM public.assets WHERE serial='VNC4H12093';
INSERT INTO public.tickets (asset_id, title, description, priority, status, raised_by_name, engineer)
SELECT id, 'RAID controller warning in iDRAC','Predictive failure on disk 3','high','in_progress','SysAdmin','N. Iyer' FROM public.assets WHERE serial='SVR-DL650-01';
