import type { ReactNode } from "react";
import { ItamSidebar } from "./itam-sidebar";
import { Search, Bell } from "lucide-react";

export function ItamLayout({
  eyebrow,
  title,
  subtitle,
  actions,
  children,
}: {
  eyebrow: string;
  title: string;
  subtitle?: string;
  actions?: ReactNode;
  children: ReactNode;
}) {
  return (
    <div className="flex min-h-screen w-full bg-[color:var(--paper)]">
      <ItamSidebar />
      <main className="flex-1 min-h-screen flex flex-col min-w-0">
        {/* Top command bar */}
        <div className="sticky top-0 z-10 backdrop-blur-md bg-[color:var(--paper)]/85 border-b border-[color:var(--hairline)]">
          <div className="flex items-center gap-4 px-8 h-14">
            <div className="flex-1 max-w-md">
              <label className="relative block">
                <Search className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-[color:var(--steel-500)]" />
                <input
                  placeholder="Search assets, tickets, licenses…"
                  className="w-full bg-white/60 border border-[color:var(--hairline)] rounded-sm pl-9 pr-3 py-1.5 text-sm placeholder:text-[color:var(--steel-500)] focus:outline-none focus:border-[color:var(--signal)]"
                />
              </label>
            </div>
            <div className="flex items-center gap-2">
              <span className="hidden md:inline font-mono-tag text-[10px] uppercase tracking-widest text-[color:var(--steel-500)]">
                {new Date().toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric" })}
              </span>
              <button className="relative h-8 w-8 grid place-items-center rounded-sm border border-[color:var(--hairline)] bg-white/60 hover:bg-white transition">
                <Bell className="h-4 w-4 text-[color:var(--ink)]" />
                <span className="absolute top-1 right-1 h-1.5 w-1.5 rounded-full bg-[color:var(--alert)]" />
              </button>
            </div>
          </div>
        </div>

        <div className="flex-1 p-8">
          <header className="mb-8 grid grid-cols-[minmax(0,1fr)_auto] items-end gap-4">
            <div className="min-w-0">
              <p className="font-mono-tag text-[11px] tracking-widest text-[color:var(--signal-dark)] uppercase">
                {eyebrow}
              </p>
              <h2 className="font-display text-3xl md:text-4xl font-semibold text-[color:var(--ink)] uppercase leading-tight truncate">
                {title}
              </h2>
              {subtitle && (
                <p className="mt-1 text-sm text-[color:var(--steel-600)] max-w-xl">{subtitle}</p>
              )}
              <div className="barcode-strip text-[color:var(--steel-300)] mt-3 w-40" />
            </div>
            <div className="shrink-0">{actions}</div>
          </header>
          {children}
        </div>
      </main>
    </div>
  );
}