import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { ItamLayout } from "@/components/itam-layout";
import { supabase } from "@/integrations/supabase/client";
import { useUserRole } from "@/hooks/use-auth";
import { Search, Laptop, Server, Network, Printer, Monitor, Smartphone, Keyboard, Package, Plus } from "lucide-react";

export const Route = createFileRoute("/_authenticated/assets")({
  head: () => ({
    meta: [
      { title: "Assets — ITAM Console" },
      { name: "description", content: "Inventory of laptops, servers, and peripherals." },
      { property: "og:title", content: "Assets — ITAM Console" },
      { property: "og:description", content: "Inventory of laptops, servers, and peripherals." },
    ],
  }),
  component: AssetsPage,
});

const STATUS_STYLES: Record<string, string> = {
  available: "bg-green-50 text-[color:var(--ok)] border-green-200",
  assigned: "bg-amber-50 text-[color:var(--signal-dark)] border-amber-200",
  in_repair: "bg-orange-50 text-[color:var(--warn)] border-orange-200",
  lost: "bg-red-50 text-[color:var(--alert)] border-red-200",
  retired: "bg-[color:var(--steel-100)] text-[color:var(--steel-500)] border-[color:var(--steel-200)]",
};

const CATEGORY_ICONS: Record<string, typeof Laptop> = {
  laptop: Laptop,
  server: Server,
  switch: Network,
  printer: Printer,
  monitor: Monitor,
  mobile: Smartphone,
  keyboard: Keyboard,
  other: Package,
};

function StatusTag({ status }: { status: string }) {
  return (
    <span className={`inline-flex items-center gap-1.5 font-mono-tag text-[11px] uppercase tracking-widest px-2 py-0.5 rounded-sm border ${STATUS_STYLES[status] || ""}`}>
      <span className="h-1.5 w-1.5 rounded-full bg-current opacity-70" />
      {status.replace("_", " ")}
    </span>
  );
}

function AssetsPage() {
  const role = useUserRole();
  const isAdmin = role === "admin";
  const qc = useQueryClient();
  const [showForm, setShowForm] = useState(false);
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<string>("all");
  const [form, setForm] = useState({ name: "", serial: "", category: "laptop" as const });

  const { data: assets = [] } = useQuery({
    queryKey: ["assets"],
    queryFn: async () => {
      const { data, error } = await supabase.from("assets").select("*").order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  const addAsset = useMutation({
    mutationFn: async (payload: typeof form) => {
      const { error } = await supabase.from("assets").insert(payload);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["assets"] });
      setShowForm(false);
      setForm({ name: "", serial: "", category: "laptop" });
    },
  });

  const filtered = assets.filter((a) => {
    const matchesQ = !query || `${a.name} ${a.serial} ${a.category}`.toLowerCase().includes(query.toLowerCase());
    const matchesF = filter === "all" || a.status === filter;
    return matchesQ && matchesF;
  });

  const statusCounts = ["all", "available", "assigned", "in_repair", "lost", "retired"].map((k) => ({
    k,
    n: k === "all" ? assets.length : assets.filter((a) => a.status === k).length,
  }));

  return (
    <ItamLayout
      eyebrow="Inventory"
      title="Assets"
      subtitle="Every serial-tagged device under your organization's control."
      actions={
        isAdmin && (
          <button
            onClick={() => setShowForm((s) => !s)}
            className="inline-flex items-center gap-2 bg-[color:var(--ink-950)] text-[color:var(--paper)] text-xs font-semibold uppercase tracking-widest px-4 py-2 rounded-sm hover:bg-[color:var(--ink-900)] transition"
          >
            {showForm ? "Cancel" : (<><Plus className="h-4 w-4" /> Add Asset</>)}
          </button>
        )
      }
    >
      {showForm && isAdmin && (
        <form
          onSubmit={(e) => { e.preventDefault(); addAsset.mutate(form); }}
          className="mb-6 bg-white rounded-sm border border-[color:var(--steel-200)] p-4 grid md:grid-cols-4 gap-3 items-end"
        >
          <div>
            <label className="text-xs font-mono-tag uppercase tracking-wide text-[color:var(--steel-500)]">Name</label>
            <input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="mt-1 w-full border border-[color:var(--steel-300)] rounded-sm px-2 py-1.5 text-sm" />
          </div>
          <div>
            <label className="text-xs font-mono-tag uppercase tracking-wide text-[color:var(--steel-500)]">Serial</label>
            <input required value={form.serial} onChange={(e) => setForm({ ...form, serial: e.target.value })} className="mt-1 w-full border border-[color:var(--steel-300)] rounded-sm px-2 py-1.5 text-sm" />
          </div>
          <div>
            <label className="text-xs font-mono-tag uppercase tracking-wide text-[color:var(--steel-500)]">Category</label>
            <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value as typeof form.category })} className="mt-1 w-full border border-[color:var(--steel-300)] rounded-sm px-2 py-1.5 text-sm bg-white">
              {["laptop","server","switch","printer","monitor","mobile","keyboard","other"].map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
          <button type="submit" disabled={addAsset.isPending} className="bg-[color:var(--signal)] text-[color:var(--ink-950)] text-sm font-semibold uppercase tracking-wide px-4 py-2 rounded-sm">
            {addAsset.isPending ? "…" : "Save"}
          </button>
          {addAsset.error && <p className="text-xs text-[color:var(--alert)] md:col-span-4">{(addAsset.error as Error).message}</p>}
        </form>
      )}

      {/* Toolbar */}
      <div className="mb-4 flex flex-wrap items-center gap-3">
        <label className="relative flex-1 min-w-[200px] max-w-md">
          <Search className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-[color:var(--steel-500)]" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search by name, serial, category…"
            className="w-full bg-white border border-[color:var(--hairline)] rounded-sm pl-9 pr-3 py-2 text-sm focus:outline-none focus:border-[color:var(--signal)]"
          />
        </label>
        <div className="flex flex-wrap gap-1">
          {statusCounts.map(({ k, n }) => (
            <button
              key={k}
              onClick={() => setFilter(k)}
              className={`font-mono-tag text-[10px] uppercase tracking-widest px-2.5 py-1.5 rounded-sm border transition ${
                filter === k
                  ? "bg-[color:var(--ink-950)] text-[color:var(--paper)] border-[color:var(--ink-950)]"
                  : "bg-white text-[color:var(--steel-600)] border-[color:var(--hairline)] hover:border-[color:var(--steel-300)]"
              }`}
            >
              {k.replace("_", " ")} <span className="opacity-60 ml-1">{n}</span>
            </button>
          ))}
        </div>
      </div>

      <div className="bg-white rounded-sm border border-[color:var(--hairline)] overflow-hidden tag-card">
        <table className="w-full text-sm">
          <thead className="bg-[color:var(--steel-50)] text-left text-[10px] uppercase tracking-widest text-[color:var(--steel-500)] font-mono-tag border-b border-[color:var(--hairline)]">
            <tr>
              <th className="px-4 py-3 w-14">Tag</th>
              <th className="px-4 py-3">Asset</th>
              <th className="px-4 py-3">Serial</th>
              <th className="px-4 py-3">Category</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3">Assigned To</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((a, i) => {
              const Icon = CATEGORY_ICONS[a.category] || Package;
              return (
                <tr key={a.id} className="border-t border-[color:var(--hairline)] hover:bg-[color:var(--steel-50)]/60 transition">
                  <td className="px-4 py-3 font-mono-tag text-[11px] text-[color:var(--steel-500)] tabular">#{String(i + 1).padStart(4, "0")}</td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <div className="h-9 w-9 grid place-items-center rounded-sm bg-[color:var(--steel-50)] border border-[color:var(--hairline)] text-[color:var(--ink)]">
                        <Icon className="h-4 w-4" />
                      </div>
                      <span className="font-medium text-[color:var(--ink)]">{a.name}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3 font-mono-tag text-[color:var(--steel-500)] tabular">{a.serial}</td>
                  <td className="px-4 py-3 text-[color:var(--steel-600)] capitalize">{a.category.replace("_", " ")}</td>
                  <td className="px-4 py-3"><StatusTag status={a.status} /></td>
                  <td className="px-4 py-3 text-[color:var(--steel-600)]">{a.assigned_to || "—"}</td>
                </tr>
              );
            })}
            {filtered.length === 0 && (
              <tr><td colSpan={6} className="px-4 py-12 text-center text-sm text-[color:var(--steel-500)]">No assets match this filter.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </ItamLayout>
  );
}