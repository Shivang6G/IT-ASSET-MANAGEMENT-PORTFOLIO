import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { ItamLayout } from "@/components/itam-layout";
import { supabase } from "@/integrations/supabase/client";
import { useAuth, useUserRole } from "@/hooks/use-auth";

export const Route = createFileRoute("/_authenticated/tickets")({
  head: () => ({
    meta: [
      { title: "Tickets — ITAM Console" },
      { name: "description", content: "Support tickets raised against IT assets." },
      { property: "og:title", content: "Tickets — ITAM Console" },
      { property: "og:description", content: "Support tickets raised against IT assets." },
    ],
  }),
  component: TicketsPage,
});

const PRIORITY: Record<string, string> = {
  low: "text-[color:var(--steel-500)] border-[color:var(--steel-200)] bg-[color:var(--steel-50)]",
  medium: "text-[color:var(--signal-dark)] border-amber-200 bg-amber-50",
  high: "text-[color:var(--warn)] border-orange-200 bg-orange-50",
  critical: "text-[color:var(--alert)] border-red-200 bg-red-50",
};
const STATUS: Record<string, string> = {
  open: "text-[color:var(--alert)]",
  in_progress: "text-[color:var(--warn)]",
  resolved: "text-[color:var(--ok)]",
  closed: "text-[color:var(--steel-500)]",
};

function TicketsPage() {
  const { user } = useAuth();
  const role = useUserRole();
  const isAdmin = role === "admin";
  const qc = useQueryClient();
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ title: "", description: "", priority: "medium" as const, asset_id: "" });

  const { data: tickets = [] } = useQuery({
    queryKey: ["tickets"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("tickets")
        .select("*, assets(name, serial)")
        .order("ticket_no", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  const { data: assets = [] } = useQuery({
    queryKey: ["assets-lite"],
    queryFn: async () => (await supabase.from("assets").select("id, name, serial").order("name")).data ?? [],
  });

  const addTicket = useMutation({
    mutationFn: async (payload: typeof form) => {
      if (!user) throw new Error("Not signed in");
      const { error } = await supabase.from("tickets").insert({
        title: payload.title,
        description: payload.description,
        priority: payload.priority,
        asset_id: payload.asset_id || null,
        raised_by: user.id,
        raised_by_name: user.user_metadata?.full_name ?? user.email,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["tickets"] });
      setShowForm(false);
      setForm({ title: "", description: "", priority: "medium", asset_id: "" });
    },
  });

  const updateStatus = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      const { error } = await supabase.from("tickets").update({ status: status as never }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["tickets"] }),
  });

  return (
    <ItamLayout
      eyebrow="Support"
      title="Tickets"
      actions={
        <button
          onClick={() => setShowForm((s) => !s)}
          className="bg-[color:var(--ink-950)] text-[color:var(--paper)] text-sm font-semibold uppercase tracking-wide px-4 py-2 rounded-sm hover:bg-[color:var(--ink-900)] transition"
        >
          {showForm ? "Cancel" : "+ Raise Ticket"}
        </button>
      }
    >
      {showForm && (
        <form
          onSubmit={(e) => { e.preventDefault(); addTicket.mutate(form); }}
          className="mb-6 bg-white rounded-sm border border-[color:var(--steel-200)] p-4 grid md:grid-cols-2 gap-3"
        >
          <div className="md:col-span-2">
            <label className="text-xs font-mono-tag uppercase tracking-wide text-[color:var(--steel-500)]">Issue title</label>
            <input required value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className="mt-1 w-full border border-[color:var(--steel-300)] rounded-sm px-2 py-1.5 text-sm" />
          </div>
          <div>
            <label className="text-xs font-mono-tag uppercase tracking-wide text-[color:var(--steel-500)]">Asset</label>
            <select value={form.asset_id} onChange={(e) => setForm({ ...form, asset_id: e.target.value })} className="mt-1 w-full border border-[color:var(--steel-300)] rounded-sm px-2 py-1.5 text-sm bg-white">
              <option value="">— none —</option>
              {assets.map((a) => <option key={a.id} value={a.id}>{a.name} ({a.serial})</option>)}
            </select>
          </div>
          <div>
            <label className="text-xs font-mono-tag uppercase tracking-wide text-[color:var(--steel-500)]">Priority</label>
            <select value={form.priority} onChange={(e) => setForm({ ...form, priority: e.target.value as typeof form.priority })} className="mt-1 w-full border border-[color:var(--steel-300)] rounded-sm px-2 py-1.5 text-sm bg-white">
              {["low","medium","high","critical"].map((p) => <option key={p} value={p}>{p}</option>)}
            </select>
          </div>
          <div className="md:col-span-2">
            <label className="text-xs font-mono-tag uppercase tracking-wide text-[color:var(--steel-500)]">Description</label>
            <textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} className="mt-1 w-full border border-[color:var(--steel-300)] rounded-sm px-2 py-1.5 text-sm min-h-[80px]" />
          </div>
          <button type="submit" disabled={addTicket.isPending} className="bg-[color:var(--signal)] text-[color:var(--ink-950)] text-sm font-semibold uppercase tracking-wide px-4 py-2 rounded-sm md:col-span-2">
            {addTicket.isPending ? "…" : "Submit ticket"}
          </button>
          {addTicket.error && <p className="text-xs text-[color:var(--alert)] md:col-span-2">{(addTicket.error as Error).message}</p>}
        </form>
      )}

      <div className="bg-white rounded-sm border border-[color:var(--steel-200)] overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-[color:var(--steel-50)] text-left text-xs uppercase tracking-widest text-[color:var(--steel-500)] font-mono-tag">
            <tr>
              <th className="px-4 py-3">#</th>
              <th className="px-4 py-3">Asset</th>
              <th className="px-4 py-3">Issue</th>
              <th className="px-4 py-3">Priority</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3">Raised by</th>
            </tr>
          </thead>
          <tbody>
            {tickets.map((t) => (
              <tr key={t.id} className="border-t border-[color:var(--steel-100)] align-top">
                <td className="px-4 py-3 font-mono-tag text-[color:var(--steel-500)]">#{t.ticket_no}</td>
                <td className="px-4 py-3 font-medium text-[color:var(--ink)]">{t.assets?.name ?? "—"}</td>
                <td className="px-4 py-3 text-[color:var(--steel-600)] max-w-xs">{t.title}</td>
                <td className="px-4 py-3">
                  <span className={`inline-block font-mono-tag text-[11px] uppercase tracking-wide px-2 py-0.5 rounded-sm border ${PRIORITY[t.priority]}`}>{t.priority}</span>
                </td>
                <td className={`px-4 py-3 font-mono-tag text-xs uppercase tracking-wide ${STATUS[t.status]}`}>
                  {isAdmin ? (
                    <select
                      value={t.status}
                      onChange={(e) => updateStatus.mutate({ id: t.id, status: e.target.value })}
                      className="bg-transparent border border-[color:var(--steel-200)] rounded-sm px-1 py-0.5 text-xs uppercase"
                    >
                      {["open","in_progress","resolved","closed"].map((s) => <option key={s} value={s}>{s.replace("_"," ")}</option>)}
                    </select>
                  ) : t.status.replace("_", " ")}
                </td>
                <td className="px-4 py-3 text-[color:var(--steel-600)]">{t.raised_by_name ?? "—"}</td>
              </tr>
            ))}
            {tickets.length === 0 && (
              <tr><td colSpan={6} className="px-4 py-8 text-center text-sm text-[color:var(--steel-500)]">No tickets yet.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </ItamLayout>
  );
}