import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { ItamLayout } from "@/components/itam-layout";
import { supabase } from "@/integrations/supabase/client";
import { KeyRound } from "lucide-react";

export const Route = createFileRoute("/_authenticated/licenses")({
  head: () => ({
    meta: [
      { title: "Licenses — ITAM Console" },
      { name: "description", content: "Software licenses, seats, and expiry tracking." },
      { property: "og:title", content: "Licenses — ITAM Console" },
      { property: "og:description", content: "Software licenses, seats, and expiry tracking." },
    ],
  }),
  component: LicensesPage,
});

function daysUntil(d: string | null) {
  if (!d) return Infinity;
  return Math.round((new Date(d).getTime() - Date.now()) / 86_400_000);
}

function LicensesPage() {
  const { data: licenses = [] } = useQuery({
    queryKey: ["licenses"],
    queryFn: async () => (await supabase.from("licenses").select("*").order("expiry", { ascending: true })).data ?? [],
  });

  return (
    <ItamLayout eyebrow="Software" title="Licenses" subtitle="Seats, vendors, and renewal timelines — one ledger.">
      <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-4">
        {licenses.map((l, i) => {
          const pct = l.seats_total ? Math.round((l.seats_used / l.seats_total) * 100) : 0;
          const days = daysUntil(l.expiry);
          const expiringSoon = days <= 30;
          const critical = pct > 90;
          return (
            <div key={l.id} className="relative bg-white rounded-sm border border-[color:var(--hairline)] p-5 tag-card overflow-hidden">
              {(critical || expiringSoon) && (
                <div className="absolute top-0 right-0 h-1 w-16 caution-stripe opacity-80" />
              )}
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-3 min-w-0">
                  <div className="h-10 w-10 shrink-0 grid place-items-center rounded-sm bg-[color:var(--ink-950)] text-[color:var(--signal)]">
                    <KeyRound className="h-4 w-4" />
                  </div>
                  <div className="min-w-0">
                    <p className="font-mono-tag text-[10px] uppercase tracking-widest text-[color:var(--steel-500)] tabular">
                      LIC-{String(i + 1).padStart(4, "0")}
                    </p>
                    <h3 className="font-display text-lg font-semibold text-[color:var(--ink)] uppercase leading-tight truncate">{l.name}</h3>
                  </div>
                </div>
                <span
                  className={`shrink-0 font-mono-tag text-[11px] uppercase tracking-widest px-2 py-0.5 rounded-sm border ${
                    expiringSoon
                      ? "bg-amber-50 text-[color:var(--warn)] border-amber-200"
                      : "bg-[color:var(--steel-50)] text-[color:var(--steel-500)] border-[color:var(--steel-200)]"
                  }`}
                >
                  {l.expiry ? (expiringSoon ? `${days}d left` : l.expiry) : "—"}
                </span>
              </div>

              <p className="font-mono-tag text-xs text-[color:var(--steel-500)] mt-3 truncate">
                Vendor · {l.vendor ?? l.key_ref ?? "—"}
              </p>

              <div className="mt-5">
                <div className="flex justify-between items-baseline text-xs font-mono-tag text-[color:var(--steel-500)] uppercase tracking-widest">
                  <span>Seats in use</span>
                  <span className="tabular text-[color:var(--ink)] font-semibold text-sm">{l.seats_used} / {l.seats_total}</span>
                </div>
                <div className="mt-2 h-2 w-full rounded-sm bg-[color:var(--steel-100)] overflow-hidden">
                  <div
                    className={`h-full ${pct > 90 ? "bg-[color:var(--alert)]" : pct > 75 ? "bg-[color:var(--signal)]" : "bg-[color:var(--ok)]"}`}
                    style={{ width: `${pct}%` }}
                  />
                </div>
                <p className="mt-1 text-[10px] font-mono-tag uppercase tracking-widest text-[color:var(--steel-500)] tabular">{pct}% utilized</p>
              </div>

              <div className="barcode-strip text-[color:var(--steel-300)] mt-4 w-full" />
            </div>
          );
        })}
        {licenses.length === 0 && (
          <p className="text-sm text-[color:var(--steel-500)]">No licenses yet.</p>
        )}
      </div>
    </ItamLayout>
  );
}