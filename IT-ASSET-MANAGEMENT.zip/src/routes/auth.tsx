import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { ShieldCheck, Boxes, LifeBuoy, KeyRound } from "lucide-react";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Sign in — ITAM Console" },
      { name: "description", content: "Sign in to the ITAM Console." },
      { property: "og:title", content: "Sign in — ITAM Console" },
      { property: "og:description", content: "Sign in to the ITAM Console." },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) navigate({ to: "/dashboard" });
    });
  }, [navigate]);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      if (mode === "signup") {
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            emailRedirectTo: window.location.origin,
            data: { full_name: fullName },
          },
        });
        if (error) throw error;
        navigate({ to: "/dashboard" });
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        navigate({ to: "/dashboard" });
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Auth failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="min-h-screen w-full grid lg:grid-cols-2 bg-[color:var(--paper)]">
      {/* Brand panel */}
      <aside className="relative hidden lg:flex flex-col justify-between p-10 bg-[color:var(--ink-950)] text-[color:var(--paper)] overflow-hidden">
        <div className="grid-paper absolute inset-0 opacity-10" />
        <div className="caution-stripe absolute top-0 inset-x-0 h-1.5 opacity-80" />
        <div className="relative flex items-center gap-3">
          <div className="h-10 w-10 rounded-sm bg-[color:var(--signal)] grid place-items-center text-[color:var(--ink-950)] font-display font-bold">IT</div>
          <div>
            <p className="font-mono-tag text-[10px] tracking-widest text-[color:var(--signal)] uppercase">Tag · 000001</p>
            <h1 className="font-display text-lg font-semibold uppercase leading-none">ITAM Console</h1>
          </div>
        </div>

        <div className="relative">
          <p className="font-mono-tag text-[11px] tracking-widest text-[color:var(--signal)] uppercase">Secure access · authorized personnel</p>
          <h2 className="font-display text-4xl xl:text-5xl font-bold uppercase leading-tight mt-3">
            Every asset<br/>tagged.<br/>Every ticket<br/>tracked.
          </h2>
          <div className="barcode-strip text-[color:var(--signal)]/70 mt-5 w-48" />
          <ul className="mt-8 space-y-3 text-sm">
            {[{Icon: Boxes, t: "Live inventory across sites, sealed by asset tag."},
              {Icon: LifeBuoy, t: "Support tickets attached directly to hardware."},
              {Icon: KeyRound, t: "License seats & renewals under one ledger."}].map((f, i) => (
              <li key={i} className="flex items-start gap-3 text-[color:var(--steel-300)]">
                <f.Icon className="h-4 w-4 mt-0.5 text-[color:var(--signal)]" />
                <span>{f.t}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="relative flex items-center justify-between text-[11px] font-mono-tag uppercase tracking-widest text-[color:var(--steel-500)]">
          <span className="flex items-center gap-2"><ShieldCheck className="h-3.5 w-3.5 text-[color:var(--ok)]" /> Encrypted · RLS enforced</span>
          <span>v.1.0</span>
        </div>
      </aside>

      {/* Form panel */}
      <div className="flex items-center justify-center px-4 py-10">
        <div className="w-full max-w-md bg-white border border-[color:var(--hairline)] rounded-sm p-8 tag-card">
          <p className="font-mono-tag text-[11px] tracking-widest text-[color:var(--signal-dark)] uppercase">
            {mode === "signin" ? "Access request" : "New credential"}
          </p>
          <h1 className="font-display text-3xl font-semibold text-[color:var(--ink)] uppercase mt-1 leading-tight">
            {mode === "signin" ? "Sign in" : "Create account"}
          </h1>
          <div className="barcode-strip text-[color:var(--steel-300)] mt-2 w-24" />

          <form onSubmit={onSubmit} className="space-y-3 mt-6">
            {mode === "signup" && (
              <div>
                <label className="text-xs font-mono-tag uppercase tracking-wide text-[color:var(--steel-500)]">Full name</label>
                <input
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  required
                  className="mt-1 w-full border border-[color:var(--steel-300)] rounded-sm px-3 py-2 text-sm focus:outline-none focus:border-[color:var(--signal)]"
                />
              </div>
            )}
            <div>
              <label className="text-xs font-mono-tag uppercase tracking-wide text-[color:var(--steel-500)]">Email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="mt-1 w-full border border-[color:var(--steel-300)] rounded-sm px-3 py-2 text-sm focus:outline-none focus:border-[color:var(--signal)]"
              />
            </div>
            <div>
              <label className="text-xs font-mono-tag uppercase tracking-wide text-[color:var(--steel-500)]">Password</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                minLength={6}
                className="mt-1 w-full border border-[color:var(--steel-300)] rounded-sm px-3 py-2 text-sm focus:outline-none focus:border-[color:var(--signal)]"
              />
            </div>

            {error && <p className="text-xs text-[color:var(--alert)]">{error}</p>}

            <button
              type="submit"
              disabled={busy}
              className="w-full bg-[color:var(--ink-950)] text-[color:var(--paper)] rounded-sm py-2.5 text-sm font-semibold uppercase tracking-wide hover:bg-[color:var(--ink-900)] transition disabled:opacity-50"
            >
              {busy ? "…" : mode === "signin" ? "Sign in" : "Create account"}
            </button>
          </form>

          <p className="mt-5 text-xs text-center text-[color:var(--steel-500)]">
            {mode === "signin" ? "Don't have an account? " : "Already have one? "}
            <button
              type="button"
              onClick={() => setMode(mode === "signin" ? "signup" : "signin")}
              className="font-semibold text-[color:var(--ink)] hover:text-[color:var(--signal-dark)] uppercase tracking-wide"
            >
              {mode === "signin" ? "Sign up" : "Sign in"}
            </button>
          </p>

          <p className="mt-4 text-center">
            <Link to="/" className="text-xs font-mono-tag uppercase tracking-widest text-[color:var(--steel-400)] hover:text-[color:var(--ink)]">← Back home</Link>
          </p>
        </div>
      </div>
    </div>
  );
}